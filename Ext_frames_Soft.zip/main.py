#bibliotecas
import os
import cv2
import clip
import torch
import shutil
import datetime
import youtube_dl
import numpy as np
from pathlib import Path
from functools import partial
import matplotlib.pyplot as plt
from multiprocessing.pool import Pool
from PIL import Image,ImageDraw, ImageFont

import clases as cl

#FIRST STEP
url = input("Youtube URL: ")
video_extractor = cl.VideoExtractor()
(skip_frames, path_frames) = video_extractor.video_to_frames(url)

#SECOND STEP
folder_path = 'frames'
query = 'A jaguar'
finder = cl.SearchImages()
matches = finder.folder_inference(folder_path, query, 526, 0.2)
