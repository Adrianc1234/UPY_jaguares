import os
import cv2
import clip
import torch
import shutil
import datetime
import youtube_dl
import numpy as np
from pathlib import Path
from functools import partial
import matplotlib.pyplot as plt
from multiprocessing.pool import Pool
from PIL import Image,ImageDraw, ImageFont

class VideoExtractor:

  def __init__(self):
    self.default_resolutions = ['480p', '360p','240p','144p']
  
  # Parse video format
  def get_video_format(self, url, ydl_opts={}, format_note='240p', ext='mp4', max_size = 500000000):
    ydl = youtube_dl.YoutubeDL(ydl_opts)
    info_dict = ydl.extract_info(url, download=False)
    formats = info_dict.get('formats', None)
    # filter out formats we can't process
    formats = [f for f in formats if f['ext'] == ext 
               and f['vcodec'].split('.')[0] != 'av01' 
               and f['filesize'] is not None and f['filesize'] <= max_size]
    available_format_notes = set([f['format_note'] for f in formats])
    
    if format_note not in available_format_notes:
      format_note = [d for d in self.default_resolutions if d in available_format_notes][0]
    formats = [f for f in formats if f['format_note'] == format_note]
    format = formats[0]
    format_id = format.get('format_id', None)
    fps = format.get('fps', None)
    print(f'format selected: {format}')
    return(format, format_id, fps)
  
  #Download video from youtube
  def download_video(self, url):
    # create "videos" foder for saved videos
    path_videos = Path('videos')
    try:
      path_videos.mkdir(parents=True)
    except FileExistsError:
      pass
    # clear the "videos" folder 
    videos_to_keep = ['v1rkzUIL8oc', 'k4R5wZs8cxI','0diCvgWv_ng']
    if len(list(path_videos.glob('*'))) > 10:
        for path_video in path_videos.glob('*'):
            if path_video.stem not in set(videos_to_keep):
                path_video.unlink()
                print(f'removed video {path_video}')
    # select format to download for given video
    try:
      format, format_id, fps = self.get_video_format(url)
      ydl_opts = {
        'format':format_id,
        'outtmpl': "videos/%(id)s.%(ext)s"}

      with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        try:
          ydl.cache.remove()
          meta = ydl.extract_info(url)
          save_location = 'videos/' + meta['id'] + '.' + meta['ext']
        except youtube_dl.DownloadError as error:
          print(f'error with download_video function: {error}')
          save_location = None
    except IndexError as err:
      print(f"can't find suitable video formats. we are not able to process video larger than 95 Mib at the moment")
      fps, save_location = None, None
    return(fps, save_location)

  # Extract frames for video 
  def extract_frames_from_video(self, video, skip_frames, dest_path, num_processes, process_number):
    cap = cv2.VideoCapture(video)
    frames_per_process = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) // (num_processes)
    count =  frames_per_process * process_number
    cap.set(cv2.CAP_PROP_POS_FRAMES, count)
    print(f"worker: {process_number}, process frames {count} ~ {frames_per_process * (process_number + 1)} \n total number of frames: {cap.get(cv2.CAP_PROP_FRAME_COUNT)} \n video: {video}; isOpen? : {cap.isOpened()}")
    while count < frames_per_process * (process_number + 1) :
        ret, frame = cap.read()
        if not ret:
            break
        if count  % skip_frames ==0:
          filename =f"{dest_path}/{count}.jpg"
          cv2.imwrite(filename, frame)
        count += 1
    cap.release()
  
  # Extract images from video frames using the sampling interval
  def video_to_frames(self, url, sampling_interval=1):
    # create folder for extracted frames - if folder exists, delete and create a new one
    path_frames = Path('frames')
    try:
        path_frames.mkdir(parents=True)
    except FileExistsError:
        shutil.rmtree(path_frames)
        path_frames.mkdir(parents=True)
 
    # download the video 
    fps, video = self.download_video(url)
    if video is not None: 
      if fps is None: fps = 30
      skip_frames = int(fps * sampling_interval)
      print(f'video saved at: {video}, fps:{fps}, skip_frames: {skip_frames}')
      # extract video frames at given sampling interval with multiprocessing - 
      n_workers = min(os.cpu_count(), 12)
      print(f'now extracting frames with {n_workers} process...')

      with Pool(n_workers) as pool:
        pool.map(partial(self.extract_frames_from_video, video, skip_frames, path_frames, n_workers), range(n_workers))
    else:
      skip_frames, path_frames = None, None
    return (skip_frames, path_frames)
    
  
class SearchImages:

  def __init__(self, threshold = 0.7):
    self.threshold = threshold
    self.device = "cuda" if torch.cuda.is_available() else "cpu"
    self.model, self.preprocess = clip.load("ViT-B/32")

  def folder_inference(self, folder_path, query, batch_size=526, threshold=None):
    matches = []
    threshold = threshold if threshold else self.threshold
    filenames = sorted(Path(folder_path).glob('*.jpg'),key=lambda p: int(p.stem))
    n_images = len(filenames)
    batch_size = min(n_images,batch_size)
    print(f"processing {n_images}, now encoding images")
    # encoding images one batch at a time, combine all batch outputs -> image_features, size n_frames x 512
    image_features = torch.empty(size=(n_images, 512),dtype=torch.float32).to(self.device)
    print(f"encoding images, batch size :{batch_size} ; number of batches: {len(range(0, n_images,batch_size))}")
    for b in range(0, n_images,batch_size):
      images = []
      # loop through all frames in the batch -> create batch_image_input, size bs x 3 x 224 x 224
      for filename in filenames[b:b+batch_size]:
        image = Image.open(filename).convert("RGB")
        images.append(self.preprocess(image))
      batch_image_input = torch.tensor(np.stack(images)).to(self.device)
      # encoding batch_image_input -> batch_image_features
      with torch.no_grad():
        batch_image_features = self.model.encode_image(batch_image_input)
        batch_image_features /= batch_image_features.norm(dim=-1, keepdim=True)
      #add encoded image embedding to image_features
      image_features[b:b+batch_size] = batch_image_features
    #encoding search query
    print(f'encoding search query')
    with torch.no_grad():
      text_features = self.model.encode_text(clip.tokenize(query).to(self.device)).to(dtype=torch.float32)
      text_features /= text_features.norm(dim=-1, keepdim=True)
    similarity = (image_features @ text_features.T)
    for i in range(similarity.shape[0]):
      if similarity[i][0] >= threshold:
        matches.append((filenames[i], similarity[i][0]))
    return matches

  def show_results(self, matches, show_images = True):
    print(f"{len(matches)} results...")
    for match in matches:
      print(match[1])
      if show_images:
        match = Image.open(match[0]).convert("RGB")
        plt.imshow(match)
        plt.show()